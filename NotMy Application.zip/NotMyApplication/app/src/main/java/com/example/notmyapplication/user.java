package com.example.notmyapplication;

import java.io.Serializable;
import java.util.ArrayList;

public class user implements Serializable {
    private String name;
    private String pass;
    private String email;
    private String key;
    private ArrayList<Meds> medlist;
     private String pic;

    public user(String name,String pass, String email,String key, String pic){
    this.name=name;
    this.pass=pass;
    this.email=email;
    this.key=key;
    this.pic=pic;
}
public user(){

}
    public String getUserName() {
        return name;
    }

    public String getPassWord() {
        return pass;
    }

    public String getEmail() {
        return this.email;
    }

    public String getKey() {
        return this.key;
    }

    public ArrayList<Meds>getMedlist() {
        return medlist;
    }

    public void setUserName(String userName) {
        this.name = userName;
    }

    public void setPassWord(String passWord) {
        this.pass = passWord;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setMedlist(ArrayList<Meds> medlist) {
        this.medlist = medlist;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }



    @Override
    public String toString()
    {
        return "com.example.databasework.user{" +
                "UserName='" + name + '\'' +
                ", PassWord='" + pass + '\'' +
                ", Email='" + email + '\'' +
                ", picture='" + pic+ '\'' +
                '}';
    }
}
