package com.example.notmyapplication;

import java.io.Serializable;

public class Doc implements Serializable {
    private String docName;
    private String docPass;
    private String docEmail;
    private String docKey;
    private String userList;

    public Doc(String name, String pass, String email, String key) {
        this.docName = name;
        this.docPass = pass;
        this.docEmail = email;
        this.docKey = key;

    }

    public Doc() {

    }

    public String getDocName() {
        return docName;
    }

    public String getDocPassWord() {
        return docPass;
    }

    public String getDocEmail() {
        return this.docEmail;
    }

    public String getDocKey() {
        return this.docKey;
    }

    public String getUserList() {
        return userList;
    }

    public void setDocName(String userName) {
        this.docName = userName;
    }

    public void setDocPassWord(String passWord) {
        this.docPass = passWord;
    }

    public void setDocEmail(String email) {
        this.docEmail = email;
    }

    public void setDocKey(String key) {
        this.docKey = key;
    }

    public void setUserList(String userList) {
        this.userList = userList;
    }

    @Override
    public String toString() {
        return "com.example.databasework.user{" +
                "UserName='" + docName + '\'' +
                ", PassWord='" + docPass + '\'' +
                ", Email='" + docEmail + '\'' +
                ", Email='" + userList + '\'' +
                '}';

    }
}