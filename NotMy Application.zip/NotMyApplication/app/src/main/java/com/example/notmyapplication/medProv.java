package com.example.notmyapplication;

import java.io.Serializable;

public class medProv implements Serializable{

        private String provName;
        private String provPass;
        private String provEmail;
        private String provKey;

        public medProv(String name, String pass, String email, String key) {
            this.provName = name;
            this.provPass = pass;
            this.provEmail = email;
            this.provKey = key;
        }

        public medProv() {

        }

        public String getDocName() {
            return provName;
        }

        public String getDocPassWord() {
            return provPass;
        }

        public String getDocEmail() {
            return this.provEmail;
        }

        public String getDocKey() {
            return this.provKey;
        }

        public void setDocName(String userName) {
            this.provName = userName;
        }

        public void setDocPassWord(String passWord) {
            this.provPass = passWord;
        }

        public void setDocEmail(String email) {
            this.provEmail = email;
        }

        public void setDocKey(String key) {
            this.provKey = key;
        }

        @Override
        public String toString() {
            return "com.example.databasework.user{" +
                    "UserName='" + provName + '\'' +
                    ", PassWord='" + provPass + '\'' +
                    ", Email='" + provEmail + '\'' +
                    '}';

        }
    }
