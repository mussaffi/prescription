package com.example.notmyapplication;

public class Meds {
    private String medName;
    private Integer amount;
    private Double price;
    private String expDate;

    public Meds(String name, Double price, String expDate)
    {
        this.medName = name;
        this.price = price;
        this.expDate = expDate;
    }

    public Meds()
    {

    }

    public String getMedName() {
        return medName;
    }

    public void setMedName(String medName) {
        this.medName = medName;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString()
    {
        return "com.example.databasework.Meds{" +
                "medName='" + medName + '\'' +
                ", amount=" + amount +
                ", price=" + price +
                ", expDate='" + expDate + '\'' +
                '}';
    }
}
