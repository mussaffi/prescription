package com.example.notmyapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class MedsReg extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "AddVegi";
    EditText name, price;
    TextView expDate;
    Button b3;

    DatePickerDialog.OnDateSetListener mDateSetListener;

    FirebaseAuth firebaseAuth;

    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    ProgressDialog p;

    DatabaseReference myref = firebaseDatabase.getReference("Meds");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meds_reg);
        name = findViewById(R.id.loginName);
        expDate = findViewById(R.id.editTextExpDate);
        expDate.setOnClickListener(this);
        mDateSetListener = new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth)
            {
                month = month + 1;
                Log.d(TAG, "onDateSet: mm/dd/yyyy: " + month + "/" + dayOfMonth + "/" + year);
                String date = month + "/" + dayOfMonth + "/" + year;
                expDate.setText(date);
            }
        };
        price = findViewById(R.id.editTextTextPrice);
        b3 = findViewById(R.id.button3);
        b3.setOnClickListener(this);
        firebaseAuth = FirebaseAuth.getInstance();
    }

    public void CreateMed() {
        p = new ProgressDialog(this);
        p.setMessage("entering Data...");
        p.show();
        double price_per_med = Double.parseDouble(price.getText().toString());
        //יצירת אובייקט מסוג User
        Meds m = new Meds(name.getText().toString(),
                price_per_med,
                expDate.getText().toString());
        myref.child(name.getText().toString()).setValue(m);

        p.dismiss();
        Toast.makeText(MedsReg.this,
                "ההכנסה הצליחה", Toast.LENGTH_LONG).show();
        Intent i= new Intent(MedsReg.this, MainActivity.class);
        startActivity(i);
    }

    @Override
    public void onClick(View view)
    {
        if (view == b3)
        {
            CreateMed();
        }

        if (view == expDate) {
            Calendar cal = Calendar.getInstance();
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);
            int day = cal.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog dialog = new DatePickerDialog(
                    MedsReg.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                    mDateSetListener,
                    year, month, day);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    }
}