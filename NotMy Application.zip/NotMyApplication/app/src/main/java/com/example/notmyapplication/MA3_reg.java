package com.example.notmyapplication;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import de.hdodenhof.circleimageview.CircleImageView;

public class MA3_reg extends AppCompatActivity implements View.OnClickListener {
    public static final int PICK_FROM_GALLERY = 1;

    EditText name;
    EditText pass;
    EditText email;

    ImageView pic;
    String picName;
    Uri uri;

    FirebaseAuth firebaseAuth;
    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    StorageReference mStorageRef;
    Button b;
    ProgressDialog p;
    // ImageView pic;


    DatabaseReference myref = firebaseDatabase.getReference("users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ma3_reg);

        name = findViewById(R.id.SP_name);
        pass = findViewById(R.id.SP_password);
        email = findViewById(R.id.SP_email);

        pic = findViewById(R.id.user_PIC);
        pic.setOnClickListener(this);

        b = findViewById(R.id.SignApp);
        b.setOnClickListener(this);
        firebaseAuth = FirebaseAuth.getInstance();
    }

    public void CreateUser() {
        p = new ProgressDialog(this);
        p.setMessage("Registration...");
        p.show();

        if (isValidate())
            firebaseAuth.createUserWithEmailAndPassword(email.getText().toString
                    (), pass.getText().toString()).addOnCompleteListener(this,
                    new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                //יצירת אובייקט מסוג User
                                user u = new user(name.getText().toString(),
                                        pass.getText().toString(),
                                        email.getText().toString(),
                                        picName,
                                        myref.getKey());
                                myref.push().setValue(u);
                                handlePermission();

                                p.dismiss();
                                Toast.makeText(MA3_reg.this,
                                        "ההרשמה הצליחה", Toast.LENGTH_LONG).show();
                                Intent i = new Intent(MA3_reg.this, MainActivity2.class);
                                i.putExtra("from signUp", true);
                                startActivity(i);
                                finish();
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(MA3_reg.this, " " + e.getMessage(), Toast.LENGTH_LONG).show();
                    p.dismiss();
                }
            });
    }

    public boolean isValidate() {
        if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
            email.setError("Invalid email");
            email.setFocusable(true);
            return false;
        } else if (pass.getText().toString().length() < 6) {
            pass.setError("password length at least 6 characters");
            pass.setFocusable(true);
            return false;
        } else if (email.getText().toString() == null) {
            email.setError("pls enter email");
            email.setFocusable(true);
            return false;
        } else if (pass.getText().toString() == null) {
            pass.setError("pls enter password");
            pass.setFocusable(true);
            return false;
        }
        return true;
    }


    @Override
    public void onClick(View v) {
        if (v == b) {
            CreateUser();
        }
        if (v == pic) {
            Intent i = new Intent();
            i.setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            //startActivityForResult(Intent.createChooser(i, "select picture"), 100);
            someActivityResultLauncher.launch(i);
        }
    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        Intent data = result.getData();
                        uri = data.getData();
                        if (uri != null) {
                            pic.setImageURI(uri);

                            //מתן שם לתמונה
                            picName = System.currentTimeMillis() + "." + getFileExtension(uri);
                        }
                    }
                }
            });

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guest_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        int id = item.getItemId();

        if (id == R.id.login) {
            Intent i = new Intent(this, MainActivity2.class);
            startActivity(i);
        } else if (id == R.id.signup) {
            Intent i = new Intent(this, MA3_reg.class);
            startActivity(i);
        } else if (id == R.id.logout) {
            Intent i = new Intent(this, MA3_reg.class);
            startActivity(i);
        }
        return true;
    }

    private void handlePermission() {
        if (ActivityCompat.checkSelfPermission(MA3_reg.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MA3_reg.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_FROM_GALLERY);
        } else {
            Toast.makeText(MA3_reg.this, "הרשאות",
                    Toast.LENGTH_LONG).show();
            mStorageRef = FirebaseStorage.getInstance()
                    .getReference("Image/Users/" + name.getText().toString());
            mStorageRef = mStorageRef.child(picName);
            mStorageRef.putFile(uri).addOnSuccessListener
                    (new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Toast.makeText(MA3_reg.this, "תמונה הועלתה",
                                    Toast.LENGTH_LONG).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(MA3_reg.this,
                            "" + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private String getFileExtension(Uri uri)//תמצא את הקישור של התמונה(uri)
    {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == 100 && data != null && data.getData() != null) {
                uri = data.getData();
                if (uri != null) {
                    pic.setImageURI(uri);

                    //מתן שם לתמונה
                    picName = System.currentTimeMillis() + "." + getFileExtension(uri);
                    //שמירת התמונה תתבצע תחת תיקיית
                    // Image/VegiHelper/vegi name
                    // התמונה נשמרת האימייל של המשתמש
                    mStorageRef = FirebaseStorage.getInstance()
                            .getReference("Image/Users/" + name.getText().toString());
                    mStorageRef = mStorageRef.child(picName);
                    mStorageRef.putFile(uri).addOnSuccessListener
                            (new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    Toast.makeText(MA3_reg.this, "תמונה הועלתה",
                                            Toast.LENGTH_LONG).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MA3_reg.this,
                                    "" + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }
    }
}
