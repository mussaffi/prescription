package com.example.notmyapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;

public class prescription_userSide extends AppCompatActivity implements View.OnClickListener
{
    ArrayList<Meds> rewardArrayList1,rewardArrayList2,rewardArrayList3;
    RecyclerView list_rewards1,list_rewards2,list_rewards3;
    DatabaseReference databaseReference;
    Meds r;

    BottomNavigationView bottomNav;

    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_user_side);

        try
        {
            view_a_list_rewards();
        }
        catch (Exception e)
        {
            Toast.makeText(prescription_userSide.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }

        /*
        bottomNav = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        Menu menu = bottomNav.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);
        bottomNav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                switch (item.getItemId())
                {
                    case R.id.action_list:
                        break;

                    case R.id.action_stock:
                        Intent i2 = new Intent(prescription_userSide.this, Stock.class);
                        i2.putExtra("from List", true);
                        startActivity(i2);
                        break;

                    case R.id.action_recipe:
                        Intent i3 = new Intent(prescription_userSide.this, Recipes.class);
                        i3.putExtra("from List", true);
                        startActivity(i3);
                        break;

                    case R.id.action_profile:
                        Intent i4 = new Intent(prescription_userSide.this, Profile.class);
                        i4.putExtra("from List", true);
                        startActivity(i4);
                        break;
                }
                return true;
            }
        });

         */

    }


    public void view_a_list_rewards()
    {
        rewardArrayList1=new ArrayList<Meds>();
        rewardArrayList2=new ArrayList<Meds>();
        rewardArrayList3=new ArrayList<Meds>();
        list_rewards1 =findViewById(R.id.list_rewards1);//ליאן בעירה אותי מחצי שינה. מסתבר שלא כי כתבתי בעירה במקום העירה.
        list_rewards2=findViewById(R.id.list_rewards2);
        list_rewards3=findViewById(R.id.list_rewards3);
        databaseReference = firebaseDatabase.getReference("Meds");
        databaseReference.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                try
                {
                    for (DataSnapshot singleSnapshot : snapshot.getChildren())
                    {
                        if (singleSnapshot.getValue() != null)
                        {
                            r=new Meds(singleSnapshot.child("name").getValue().toString()
                                    , Double.parseDouble(singleSnapshot.child("price").getValue().toString())
                                    , singleSnapshot.child("expDate").getValue().toString());
                            if(r.getMedName().matches("^[a-g].*$")){rewardArrayList1.add(r);}
                            if(r.getMedName().matches("^[h-n].*$")){rewardArrayList2.add(r);}
                            if(r.getMedName().matches("^[m-z].*$")){rewardArrayList3.add(r);}
                        }
                    }
                    if(r!=null)
                    {
                        Pus_Adapter adapter_reward1 = new Pus_Adapter(prescription_userSide.this, rewardArrayList1);
                        list_rewards1.setLayoutManager(new LinearLayoutManager(prescription_userSide.this));
                        list_rewards1.setLayoutManager(new LinearLayoutManager(prescription_userSide.this, LinearLayoutManager.HORIZONTAL, false));
                        adapter_reward1.setColor(R.color.gray);
                        list_rewards1.setAdapter(adapter_reward1);

                        Pus_Adapter adapter_reward2 = new Pus_Adapter(prescription_userSide.this, rewardArrayList2);
                        list_rewards2.setLayoutManager(new LinearLayoutManager(prescription_userSide.this));
                        list_rewards2.setLayoutManager(new LinearLayoutManager(prescription_userSide.this, LinearLayoutManager.HORIZONTAL, false));
                        adapter_reward2.setColor(R.color.gray);
                        list_rewards2.setAdapter(adapter_reward2);

                        Pus_Adapter adapter_reward3 = new Pus_Adapter(prescription_userSide.this, rewardArrayList3);
                        list_rewards3.setLayoutManager(new LinearLayoutManager(prescription_userSide.this));
                        list_rewards3.setLayoutManager(new LinearLayoutManager(prescription_userSide.this, LinearLayoutManager.HORIZONTAL, false));
                        adapter_reward3.setColor(R.color.gray);
                        list_rewards3.setAdapter(adapter_reward3);

                    }
                }
                catch (Exception e)
                {
                    Toast.makeText(prescription_userSide.this, e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error)
            {

            }
        });
    }


    @Override
    public void onClick(View view) {

    }
}