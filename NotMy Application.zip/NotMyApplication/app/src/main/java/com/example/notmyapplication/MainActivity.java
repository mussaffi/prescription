package com.example.notmyapplication;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    SharedPreferences spU,spD;
    FirebaseAuth firebaseAuth;
    Intent in;

    BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        in=getIntent();
        spU=getSharedPreferences("users",0);
        spD=getSharedPreferences("Doctors",0);
        firebaseAuth = FirebaseAuth.getInstance();

        bottomNav = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        Menu menu = bottomNav.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);
        bottomNav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                switch (item.getItemId())
                {
                    case R.id.home:
                        break;

                    case R.id.logout:
                        if (spU.getBoolean("isChecked", false))
                        {
                            SharedPreferences.Editor editor1 = spU.edit();
                            editor1.putBoolean("isChecked", false);
                            editor1.commit();
                        }
                        else if(spD.getBoolean("isChecked", false))
                        {
                            SharedPreferences.Editor editor2 = spD.edit();
                            editor2.putBoolean("isChecked", false);
                            editor2.commit();
                        }
                        firebaseAuth.signOut();
                        finish();
                        Intent go=new Intent(MainActivity.this, MainActivity.class);
                        startActivity(go);
                        break;

                    case R.id.Meds:
                        Intent i3 = new Intent(MainActivity.this, prescription_docSide.class);
                        i3.putExtra("from List", true);
                        startActivity(i3);
                        break;

                    case R.id.userList:
                        /*
                        Intent i4 = new Intent(MainActivity.this, Profile.class);
                        i4.putExtra("from List", true);
                        startActivity(i4);
                         */
                        break;
                }
                return true;
            }
        });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)//להוסיף אופציית דר חוזר
    {
        if (spU.getBoolean("isChecked", false)
                || (spD.getBoolean("isChecked", false)
                || (in!=null&&in.getBooleanExtra("from user_login",false)
                || (in!=null&&in.getBooleanExtra("from doc_login",false)))))
        {
            if(in!=null&&in.getBooleanExtra("from user_login",false))
                getMenuInflater().inflate(R.menu.user_menu,menu);
            else
                getMenuInflater().inflate(R.menu.bottom_menu,menu);
        }
        else
            getMenuInflater().inflate(R.menu.guest_menu,menu);

        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        super.onOptionsItemSelected(item);
        int id=item.getItemId();

        if(id==R.id.login)
        {
            Intent i=new Intent(MainActivity.this, MainActivity2.class);
            startActivity(i);
        }
        else if(id==R.id.signup)
        {
            Intent i=new Intent(MainActivity.this, MA3_reg.class);
            startActivity(i);
        }
        else if(id==R.id.logout)
        {
            if (spU.getBoolean("isChecked", false))
            {
                SharedPreferences.Editor editor1 = spU.edit();
                editor1.putBoolean("isChecked", false);
                editor1.commit();
            }
            else if(spD.getBoolean("isChecked", false))
            {
                SharedPreferences.Editor editor2 = spD.edit();
                editor2.putBoolean("isChecked", false);
                editor2.commit();
            }
            firebaseAuth.signOut();
            finish();
            Intent go=new Intent(MainActivity.this, MainActivity.class);
            startActivity(go);
        }
        else if(id==R.id.docLogin){
            Intent i=new Intent(MainActivity.this, doc_login.class);
            startActivity(i);
        }
        else if(id==R.id.docReg){
            Intent i=new Intent(MainActivity.this, MA3_reg_doc.class);
            startActivity(i);
        }
        else if(id==R.id.Meds){
            Intent i=new Intent(MainActivity.this, MedsReg.class);
            startActivity(i);
        }
        else if(id==R.id.prescription){
            Intent i=new Intent(MainActivity.this, prescription_userSide.class);
            startActivity(i);
        }
        return true;
    }

    }








