package com.example.notmyapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Doc_User_List extends AppCompatActivity {
    private static final int PICK_FROM_GALLERY = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_user_list);

    }
}