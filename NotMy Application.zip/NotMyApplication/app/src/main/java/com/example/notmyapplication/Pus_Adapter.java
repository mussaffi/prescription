package com.example.notmyapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Pus_Adapter extends RecyclerView.Adapter<Pus_Adapter.viewHolder>
{
    private Context context;
    private ArrayList<Meds> rewardArrayList;
    private ItemClickListener clickListener;
    private int color;
    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    StorageReference storageReference;

    public Pus_Adapter(Context context, ArrayList<Meds> taskArrayList)
    {
        this.context = context;
        this.rewardArrayList = taskArrayList;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(this.context);
        View view = layoutInflater.inflate(R.layout.medcell, parent, false);
        return new Pus_Adapter.viewHolder(view);//ח את העצם שקוראים לו תרופה ותדפיז אותו בlayout שבנית
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
        Meds r = this.rewardArrayList.get(position);
        holder.name.setText(r.getMedName());
        holder.price.setText(String.valueOf(r.getPrice()));
        holder.amount.setText(r.getAmount());
        holder.expDate.setText(r.getExpDate());

        /*
        storageReference = FirebaseStorage.getInstance().getReference("Image/VegiHelper/" + r.getMedName());
        storageReference = storageReference.child(r.getPic());
        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                //Picasso.with(context).load(uri).into(holder.pic);


            }
        });
         */
    }

    @Override
    public int getItemCount() {
        return this.rewardArrayList.size();
    }

    public void setClickListener(ItemClickListener itemClickListener)
    {
        this.clickListener = itemClickListener;
    }

    public void setColor(int color)
    {
        this.color = color;
    }

    public class viewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        TextView name,price,amount,expDate;
        //RoundedImageView pic;
        MaterialCardView materialCardView;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            price = itemView.findViewById(R.id.price);
            amount = itemView.findViewById(R.id.amount);
            expDate = itemView.findViewById(R.id.exDate);
             //pic = itemView.findViewById(R.id.Vegi_PIC);
            materialCardView = itemView.findViewById(R.id.cs);
            itemView.setOnClickListener(this::onClick);
        }

        @Override
        public void onClick(View view) {
            if (clickListener != null) {
                clickListener.onClick(view, getPosition());
            }
        }
    }
}