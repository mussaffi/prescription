package com.example.notmyapplication;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view, int position);
}
